10:18:34.491482: read 4096 bytes from stdin
10:18:34.519016: wrote 4096 bytes to socket
10:18:34.544636: read 4096 bytes from stdin
10:18:34.568505: read 3508 bytes from socket
10:18:34.593354: wrote 3508 bytes to stdout
10:18:34.618062: wrote 4096 bytes to socket
10:18:34.643524: read 4096 bytes from stdin
10:18:34.667305: read 2636 bytes from socket
10:18:34.691039: wrote 2636 bytes to stdout
10:18:34.697238: wrote 4096 bytes to socket
10:18:34.700582: read 4096 bytes from stdin
10:18:34.703809: read 2048 bytes from socket
10:18:34.708440: wrote 2048 bytes to stdout
10:18:34.712738: wrote 4096 bytes to socket
10:18:34.716194: read 4096 bytes from stdin
10:18:34.719832: read 4096 bytes from socket
10:18:34.724106: wrote 4096 bytes to stdout
10:18:34.728503: wrote 4096 bytes to socket
10:18:34.731839: read 3649 bytes from stdin
10:18:34.735129: read 4096 bytes from socket
10:18:34.778481: wrote 4096 bytes to stdout
10:18:34.803742: wrote 3649 bytes to socket
10:18:34.829483: EOF on stdin
10:18:34.849752: read 4096 bytes from socket
10:18:34.874733: wrote 4096 bytes to stdout
10:18:34.898581: read 3649 bytes from socket
10:18:34.923059: wrote 3649 bytes to stdout
10:18:34.946892: EOF on socket
